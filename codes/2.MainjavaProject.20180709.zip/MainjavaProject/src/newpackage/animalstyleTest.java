package newpackage;
class animalstyleTest {
    public static void main(String[] args) {
        Animal cat = new Animal() ;
        
        cat.Name = " xiaobai";
        cat.name();
        
        cat.Age = 6;
        cat.age();
}
}
