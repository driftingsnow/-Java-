package newpackage;

class casting {
    public static void main (String[] args){
        double a = 23.43; // a is variable
        int b = 10;
        int a1 = (int) a; 
        int ab = a1 + b; // implicit cast
        
        System.out.println(ab); 
        
        Integer number = new Integer (330);  //number is object   should use method 
        int destination = number.intValue();
        System.out.println(destination);  // no need to casting 
        
        int num = 124;           // -2 billion to 2 billion
        byte num1 = (byte) num; //byte ranges about -127 to 127  explicit cast 
        System.out.println(num1); 
        
        String val = "456";
        int val1 = Integer.parseInt(val); // int(data type) Integer(Object), char Character, byte Byte
        System.out.println(val);
        System.out.println(val1);

        
/*        String word = "792";
        int word1 = (String) word;
        System.out.println(word1);  //String cant casting int
*/        


/*        
        double a = 23.43;
        int b = 10;
        int ab = a + b;
        
        System.out.println(ab); 
*/
/*
        double a = 23.443;
        int b = 10;
        double ab = a + b;
        
        System.out.println(ab); // get 33.443
*/
    }
}