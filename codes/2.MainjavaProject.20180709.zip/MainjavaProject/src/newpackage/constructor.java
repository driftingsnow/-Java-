package newpackage;
public class constructor {
    int number1;
    int number2;
    
    public int getnumber(){
    return (number1 + number2);        
    }
    
    constructor(int A , int B){      // the same name as class;What I confused is why we should make another constructor.It's like class.
        number1 = A;
        number2 = B;
        
    }
}  
