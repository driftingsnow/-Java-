package newpackage;

public class constructorTest {
    
    public static void main(String[] args){
        constructor additiontest = new constructor(11,2);
        System.out.println(additiontest.getnumber());
    }
    
}