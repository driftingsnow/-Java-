package newpackage;

class forloop{
    
    public static void main(String[] args){
        for (int start = 0; start <= 10; start+=3){            
        System.out.println(start);        
        };
    }
    
}

// line6_ start++/start+=