package newpackage;
public class superdog {
// This is a super class
    int Age = 7;
    
    public void displayAge(){
        System.out.println("It is " + Age + " years old");
    }
    
}