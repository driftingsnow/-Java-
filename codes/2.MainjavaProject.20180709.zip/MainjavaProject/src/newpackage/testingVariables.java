package newpackage;

class testingVariables {
    public static void main(String[] args){
        char letter = 'I';    
        int number1 = 25;
        double number2 = 25.0;
        float number3 = 2;
        String sentence = "LOVE U";
        boolean isThatTrue = true;
    System.out.print(number1+number2+number3);
    System.out.print(" "+letter+" "+sentence+" ");
    System.out.print(isThatTrue);
    }
}
