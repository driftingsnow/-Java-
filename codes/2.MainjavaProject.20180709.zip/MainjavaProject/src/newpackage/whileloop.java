package newpackage;

class whileloop {
    
public static void main(String[] args) {
    
    int num1 = 7;
    int num2 = 3;
    
    while (num2 < num1){
        System.out.println (num2);
        num2++;
    }
    
}

}
 //if the original num2 = 8,it will also build successful.Maybe because it will not run the while loop.It skiped the while loop.