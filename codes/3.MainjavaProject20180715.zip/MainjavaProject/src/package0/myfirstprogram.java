package package0;

class myfirstprogram {
    public static void main (String[] args) {
        System.out.print ("This is my first program 2018.7.4");
    }
}