package package0;

class stringandSystemPrintout{
    public static void main(String[] args){
        String sentence0 = "He said \"Tomorrow is Friday.\"  \nI was very happy.";
        System.out.println(sentence0);
        
        
        
        String sentence1 = "EJ is American";
        String upperCase =sentence1.toUpperCase();
        System.out.println(upperCase);
        
        int index = sentence1.indexOf("a");
        System.out.println(index);
    
}
}