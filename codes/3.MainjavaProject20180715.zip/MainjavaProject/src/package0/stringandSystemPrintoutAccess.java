package package0;

public class stringandSystemPrintoutAccess{
    
         private int num0 = 1;
         private int num1 = 2;
         private int num2 = 5;
         private int sum = num0 + num1 + num2;
    
        public int sum(){
        return (sum);        // no void, return
        }

    public stringandSystemPrintoutAccess(int A, int B, int C){
        num0 = A;
        num1 = B;
        num2 = C;
        sum = num0 + num1 + num2;
        
    }
    
    public int showSumReturn(){
        return (sum);
    }
    
    public void showSumVoid(){
        System.out.println(sum); // void,not use return;
    }
}