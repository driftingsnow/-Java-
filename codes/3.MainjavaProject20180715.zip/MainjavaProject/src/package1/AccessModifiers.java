package package1;
import package0.stringandSystemPrintoutAccess;
public class AccessModifiers {
    public static void main (String[] args){
    stringandSystemPrintoutAccess testAccess = new stringandSystemPrintoutAccess(22,133,44);
    System.out.println(testAccess.sum());   
 
    stringandSystemPrintoutAccess newsumreturn = new stringandSystemPrintoutAccess(1,20,3000);
    System.out.println(newsumreturn.showSumReturn());

    stringandSystemPrintoutAccess newsumvoid = new stringandSystemPrintoutAccess(1,20,300);
    newsumvoid.showSumVoid();
    }
    
}