package package1;

public class Animal {

    String Name;
    int Age;
    
//    int animalAge;
    
    public void name() {
        System.out.println("The animal is called" + Name);
}   
    public void age() {
        System.out.println("The animal is " + Age + " years old");
}   
    
//    public void age() {
//        System.out.println(animalAge);
//    }
    

}