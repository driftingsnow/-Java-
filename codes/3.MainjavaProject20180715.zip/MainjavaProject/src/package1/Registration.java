package package1;

public class Registration{
    
    public static String username = ""; // "" can be blank
    public static int usernameCount = 0;
    int getUsernameCount; 
    public Registration(){
         
     }
    
 /*   Registration(String A){
        username = A + " "+ username;   //loop should use static to remember database line4
        usernameCount++;//loop should use static to remember database line5
    }
 */
    
    public  String getUsername(){
        return username;
    }
    
    public  int getUsernameCount(){
        return usernameCount;
    }
    
}