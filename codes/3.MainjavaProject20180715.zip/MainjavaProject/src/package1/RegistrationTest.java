package package1;



public class RegistrationTest{
    
    
    static int num1 = 777;
    public static void main(String[] args) {
    
    int num1 = 4;
    System.out.print(num1);
    
    Registration.username = "Dalyn"; //class will be OK
    System.out.println(Registration.username);  //class.username is OK
        
    Registration newuser1 = new Registration();   
    newuser1.username = "Skj0";
    newuser1.usernameCount++;
    System.out.println(newuser1.getUsername());
    System.out.println(newuser1.getUsernameCount());
    
    Registration newuser2 = new Registration();  
    newuser1.username = "Skj1";
    newuser2.usernameCount++;
    System.out.println(newuser2.getUsername());
    System.out.println(newuser2.getUsernameCount());
    
    Registration newuser3 = new Registration();   
    newuser1.username = "Skj2";
    newuser3.usernameCount = 5; //reset to 5
    System.out.println(newuser3.getUsername());
    System.out.println(newuser3.getUsernameCount());
    
        
/*  Registration user1 = new Registration("Jenny");
    System.out.println(user1.getUsername());
    System.out.println(user1.getUsernameCount());

    Registration user2 = new Registration("Dano");
    System.out.println(user2.getUsername());
    System.out.println(user2.getUsernameCount());
    
    Registration user3 = new Registration("Tianyu");
    System.out.println(user3.getUsername());
    System.out.println(user3.getUsernameCount());
*/    
    }
    
    static void getnumber(){
        System.out.println(num1);
    }
    
    
   
}