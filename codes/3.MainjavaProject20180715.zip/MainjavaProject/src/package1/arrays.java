package package1;

class arrays {
    public static void main(String[] args){
        String[] animals = {"dog","panda"};
        
        System.out.println(animals[0]);
    }
}

/*class arrays {
    public static void main(String[] args){
        String[] animals = new String[2];
        animals [0] = "dog";
        animals [1] = "panda";
        System.out.println(animals[0]);
    }
}
*/