/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

/**
 *
 * @author apple
 */
public class ifstatement {
    public static void main(String[] args){
        
        int num = 8;
        if (num == 6){
            System.out.println("Yes,it is Six.");
        }
        else {
            System.out.println("No,it isn't six");
        }
        
    }
//others != >= <=

}

