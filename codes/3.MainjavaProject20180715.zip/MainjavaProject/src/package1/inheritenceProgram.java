package package1;

public class inheritenceProgram  {
    
    public static void main(String[] args){
        
        subdog Xiaobai = new subdog();
        
        Xiaobai.Style = "Beijing Dog";
        Xiaobai.displayStyle();
        Xiaobai.Age = 12;
        Xiaobai.displayAge();
        
        
    }
}