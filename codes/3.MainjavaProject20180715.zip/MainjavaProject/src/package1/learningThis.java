package package1;
public class learningThis{
    
    int one;   //object or instance variable
    
    learningThis(int X){        
        one = X; //local variable
        System.out.println(one); 
    }
    


public static void main(String[] args){
    learningThis testThis = new learningThis(79);
    System.out.println(testThis.one);
}

}