package package1;

public class subdog extends superdog{
// This is a sub class    
    String Style;
    
    public void displayStyle(){
        System.out.println("It is a/an "+Style);
    }
}