package package1;

class switchStatement {
    public static void main(String[] args){
        int num = 3;
        
        switch (num) {
        
        case 1:
            System.out.println("It is One,not three");
            break;
            
        case 3:
            System.out.println("Yes,it is Three");
            break;
        
        default:
            System.out.println("No one matches");
            break;
            }
    
    }
}