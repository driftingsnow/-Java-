package package2;
public class DefaultConstructor{

    int a = 7;
    int b = 8;
    
/*
    DefaultConstructor(){
    a = 9;
}    
*/
    
public static void main(String[] args){
    DefaultConstructor test = new DefaultConstructor();//Java will create a default constructor when you didnt created
    System.out.println(test.a);
}

}