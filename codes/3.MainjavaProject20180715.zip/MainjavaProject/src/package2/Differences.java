/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package2;

/**
 *
 * @author apple
 */
public class Differences {
    
    int num1 = 6;
    
    
    Differences(){
        System.out.println("This is a Constructor");
    }
    
    public void getSentence(){
        System.out.println("This is the first method");
    }
    
    int getNUmber(){
        return num1; 
    }
    
    


public static void main(String[] args){
    Differences test = new Differences();
    test.getSentence();
    System.out.println(test.getNUmber());    
    }    
}
