/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package2;

/**
 *
 * @author apple
 */
// about superß
public class Subclass extends Superclass {     //childclass
                                               
public void getSentence(){  
    super.getSentence();
    System.out.println("This is from subclass");        
} 

public static void main(String[] args){    
    Subclass test = new Subclass();
    test.getSentence();
}

}
